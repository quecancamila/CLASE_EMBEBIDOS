#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#ifdef _WIN32
    #define CLEAR_SCREEN "cls"
#else
    #define CLEAR_SCREEN "clear"
#endif

#define CLAVE 0x3BAD0016

struct timeval stop, start;
void imprimeCuadrado();
void mostrarHoraEnBinario(struct tm *hora);
unsigned long obtenerTiempoMs(void);

int main() {
    gettimeofday(&start, NULL);
    unsigned long tiempoMs, tokenEsperado;
    unsigned long tokenIngresado;
    unsigned long tiempoUltimaActualizacion = 0;
    char input[20];
    int i;

    printf("Pulse Enter para iniciar la sincronizacion...\n");
    getchar();
    // Obtener la hora actual y sumarle 10 segundos
    struct timeval tiempo_actual;
    gettimeofday(&tiempo_actual, NULL);
    time_t tiempo_segundos = tiempo_actual.tv_sec + 10; // Sumar 10 segundos
    struct tm hora_local = *localtime(&tiempo_segundos);

    // Codificar la hora en binario y parpadear seg�n el esquema
  // Codificar la hora en binario y parpadear seg�n el esquema
int valores[6] = {
    hora_local.tm_hour / 10, hora_local.tm_hour % 10,
    hora_local.tm_min / 10, hora_local.tm_min % 10,
    hora_local.tm_sec / 10, hora_local.tm_sec % 10
};

    for (i = 0; i < 24; i++) {
        system(CLEAR_SCREEN);
        imprimeCuadrado();
        fflush(stdout);
        usleep(100000);

        system(CLEAR_SCREEN);
        fflush(stdout);
        usleep(80000);

        system(CLEAR_SCREEN);
        imprimeCuadrado();
        fflush(stdout);
        usleep(45000);
    }

    while (1) {
        gettimeofday(&stop, NULL);
        tiempoMs = obtenerTiempoMs();

        // Si han pasado 10 segundos, actualizar el token
        if ((tiempoMs - tiempoUltimaActualizacion) >= 10000) {
            tiempoUltimaActualizacion = tiempoMs;
            tokenEsperado = tiempoUltimaActualizacion ^ CLAVE;

        }

        printf("Tiempo usado para XOR (ms): %lu\n", tiempoMs);
        printf("Tiempo usado para XOR (hex): %08lX\n", tiempoMs);
        printf("TOKEN ESPERADO: %08lX\n", tokenEsperado);

        // Pedir el token al usuario
        printf("\nIngrese su TOKEN (8 caracteres hexadecimales o 'exit' para salir): ");
        scanf("%s", input);

        if (strcmp(input, "exit") == 0) {
            printf("Saliendo del programa...\n");
            break;
        }

        if (sscanf(input, "%8lx", &tokenIngresado) != 1) {
            printf("Entrada inv�lida. Intente nuevamente.\n");
            continue;
        }

        // Verificaci�n del TOKEN
        unsigned long tiempoActual = obtenerTiempoMs();
        unsigned long tokenActual = tiempoActual ^ CLAVE;


        if(tiempoActual - tiempoUltimaActualizacion >= 10000) {
           tiempoUltimaActualizacion = tiempoActual;  // Actualizar referencia
           tokenEsperado = tiempoUltimaActualizacion ^ CLAVE;  // Generar nuevo token
}


        if (tokenIngresado == tokenEsperado) {
        printf(" TOKEN CORRECTO \n\n");
        } else {
        printf(" TOKEN INCORRECTO  (TOKEN EXPIRADO O INCORRECTO)\n\n");
}
    }

    return 0;
}

void imprimeCuadrado() {
    unsigned char dato = 219;
    int i;
    for (i = 1; i <= 50; i++) {
        printf("%c", dato);
        if (i % 10 == 0) printf("\n");
    }
    fflush(stdout);
}

void mostrarHoraEnBinario(struct tm *hora) {
    int valores[6] = {
        hora->tm_hour / 10, hora->tm_hour % 10,
        hora->tm_min / 10, hora->tm_min % 10,
        hora->tm_sec / 10, hora->tm_sec % 10
    };
    int i;
    for (i = 0; i < 6; i++) {
        int j;
        for (j = 3; j >= 0; j--) {
            printf("%d", (valores[i] >> j) & 1);
        }
        printf(" ");
    }
    printf("\n");
    fflush(stdout);
}

// Obtiene el tiempo en milisegundos y asegura que coincida con la hora impresa
unsigned long obtenerTiempoMs(void) {  // CORREGIDO: Definici�n sin argumentos
    struct timeval tiempo_actual;
    gettimeofday(&tiempo_actual, NULL);  // Captura el tiempo UNA SOLA VEZ

    time_t tiempo_segundos = tiempo_actual.tv_sec;
    struct tm hora_local = *localtime(&tiempo_segundos);  // Misma hora que imprimimos

    // Imprimir la hora en decimal ANTES de hacer cualquier c�lculo
    printf("\nHora local en decimal: %02d:%02d:%02d\n",
           hora_local.tm_hour, hora_local.tm_min, hora_local.tm_sec);

    printf("Hora local en binario: ");
    mostrarHoraEnBinario(&hora_local);

    // Convierte la misma hora impresa a milisegundos
    unsigned long tiempoMs = ((hora_local.tm_hour * 3600) +
                             (hora_local.tm_min * 60) +
                             (hora_local.tm_sec))*1000;

    return tiempoMs;
}
