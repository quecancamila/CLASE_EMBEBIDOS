#include <stdio.h>
#include <sys/time.h>

struct timeval stop, start;
unsigned long tiempo; //4 bytes, entonces clave de 4 bytes
unsigned long clave = 0x3BAD0016;
unsigned long tokenLocal = 0;
unsigned int item_usuario = 0;
unsigned long tiemporedondedo = 0;
unsigned char byte_MS = 0;

void imprimeCuadrado();

int main(){
    printf("Pulse enter para sincronizar...");
    getchar();
    imprimeCuadrado();
    gettimeofday(&start, NULL);

    while(1)
    {
    printf("Ingrese su TOKEN>>\n");
    scanf("%2x", &item_usuario);
    gettimeofday(&stop, NULL);
    tiempo = ((stop.tv_sec - start.tv_sec) * 1000000 + stop.tv_usec - start.tv_usec);
    tiempo/=1000.0;
    tiempo=(tiempo/30000)*30000;
    tokenLocal = tiempo^clave;
    byte_MS = tokenLocal & 0xFF;

    if (item_usuario == (byte_MS))
    {
        printf("Token Correcto \n");
    }
    else
    {
        printf("Token incorrecto \n");
    }
    /*printf("Tiempo %lu ms\n", tiempo);
    printf("Tiempo %08X \n", tiempo);
    printf("Clave %08X \n", clave);
    printf("Token %08X \n", tokenLocal); */
    }
    return 0;
}

void imprimeCuadrado(){
    unsigned char dato = 219;
    int i = 0;
    for(i = 1; i < 289; i++){
        printf("%c",dato);
        if(0==(i%24))printf("\n");
    }
}
