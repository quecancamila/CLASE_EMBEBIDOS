/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QComboBox *comboBox;
    QPushButton *pushButton;
    QLabel *label_2;
    QLabel *label_3;
    QCustomPlot *customPlot;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QLabel *Titulo;
    QLabel *Titulo_2;
    QLabel *Titulo_3;
    QLabel *Titulo_4;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *Titulo_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_9;
    QLabel *Titulo_6;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *Titulo_7;
    QPushButton *Button_log;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_14;
    QPushButton *pushButton_5;
    QLabel *Titulo_8;
    QLabel *label_13;
    QLabel *label_15;
    QLineEdit *lineEdit;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1148, 813);
        comboBox = new QComboBox(Widget);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(100, 130, 181, 24));
        comboBox->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(310, 130, 141, 25));
        pushButton->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(180, 460, 61, 31));
        QFont font;
        font.setPointSize(12);
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_3 = new QLabel(Widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(110, 460, 71, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("MS Serif"));
        font1.setPointSize(12);
        label_3->setFont(font1);
        label_3->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        customPlot = new QCustomPlot(Widget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        customPlot->setGeometry(QRect(580, 120, 551, 561));
        gridLayoutWidget_2 = new QWidget(Widget);
        gridLayoutWidget_2->setObjectName(QString::fromUtf8("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(10, 20, 1121, 31));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        Titulo = new QLabel(gridLayoutWidget_2);
        Titulo->setObjectName(QString::fromUtf8("Titulo"));
        Titulo->setStyleSheet(QString::fromUtf8("        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"background-color: #c2c2c2;\n"
"color: #000;\n"
""));
        Titulo->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(Titulo, 1, 0, 1, 1);

        Titulo_2 = new QLabel(Widget);
        Titulo_2->setObjectName(QString::fromUtf8("Titulo_2"));
        Titulo_2->setGeometry(QRect(580, 80, 551, 29));
        Titulo_2->setStyleSheet(QString::fromUtf8("        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"background-color: #c2c2c2;\n"
"color: #000;\n"
""));
        Titulo_2->setAlignment(Qt::AlignCenter);
        Titulo_3 = new QLabel(Widget);
        Titulo_3->setObjectName(QString::fromUtf8("Titulo_3"));
        Titulo_3->setGeometry(QRect(10, 80, 551, 29));
        Titulo_3->setStyleSheet(QString::fromUtf8("background-color: #c2c2c2;\n"
"color: #000;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;"));
        Titulo_3->setAlignment(Qt::AlignCenter);
        Titulo_4 = new QLabel(Widget);
        Titulo_4->setObjectName(QString::fromUtf8("Titulo_4"));
        Titulo_4->setGeometry(QRect(20, 410, 551, 29));
        Titulo_4->setStyleSheet(QString::fromUtf8("background-color: #c2c2c2;\n"
"color: #000;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;"));
        Titulo_4->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(Widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(60, 500, 111, 31));
        label_4->setFont(font1);
        label_4->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_5 = new QLabel(Widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(60, 540, 121, 31));
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        Titulo_5 = new QLabel(Widget);
        Titulo_5->setObjectName(QString::fromUtf8("Titulo_5"));
        Titulo_5->setGeometry(QRect(20, 590, 551, 29));
        Titulo_5->setStyleSheet(QString::fromUtf8("background-color: #c2c2c2;\n"
"color: #000;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;"));
        Titulo_5->setAlignment(Qt::AlignCenter);
        label_6 = new QLabel(Widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 640, 161, 31));
        label_6->setFont(font1);
        label_6->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_7 = new QLabel(Widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(30, 680, 171, 31));
        label_7->setFont(font1);
        label_7->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_9 = new QLabel(Widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(30, 720, 301, 31));
        label_9->setFont(font1);
        label_9->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        Titulo_6 = new QLabel(Widget);
        Titulo_6->setObjectName(QString::fromUtf8("Titulo_6"));
        Titulo_6->setGeometry(QRect(10, 190, 551, 29));
        Titulo_6->setStyleSheet(QString::fromUtf8("background-color: #c2c2c2;\n"
"color: #000;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;"));
        Titulo_6->setAlignment(Qt::AlignCenter);
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(130, 250, 141, 25));
        pushButton_2->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));
        pushButton_3 = new QPushButton(Widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(310, 250, 141, 25));
        pushButton_3->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));
        Titulo_7 = new QLabel(Widget);
        Titulo_7->setObjectName(QString::fromUtf8("Titulo_7"));
        Titulo_7->setGeometry(QRect(580, 710, 551, 29));
        Titulo_7->setStyleSheet(QString::fromUtf8("background-color: #c2c2c2;\n"
"color: #000;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;"));
        Titulo_7->setAlignment(Qt::AlignCenter);
        Button_log = new QPushButton(Widget);
        Button_log->setObjectName(QString::fromUtf8("Button_log"));
        Button_log->setGeometry(QRect(720, 760, 251, 25));
        Button_log->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));
        label_10 = new QLabel(Widget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(180, 500, 61, 31));
        label_10->setFont(font);
        label_10->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_11 = new QLabel(Widget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(180, 540, 61, 31));
        label_11->setFont(font);
        label_11->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_12 = new QLabel(Widget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(190, 680, 131, 31));
        QFont font2;
        font2.setPointSize(10);
        label_12->setFont(font2);
        label_12->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_14 = new QLabel(Widget);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(180, 640, 111, 31));
        label_14->setFont(font2);
        label_14->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        pushButton_5 = new QPushButton(Widget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(460, 730, 91, 25));
        pushButton_5->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));
        Titulo_8 = new QLabel(Widget);
        Titulo_8->setObjectName(QString::fromUtf8("Titulo_8"));
        Titulo_8->setGeometry(QRect(10, 300, 551, 29));
        Titulo_8->setStyleSheet(QString::fromUtf8("background-color: #c2c2c2;\n"
"color: #000;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;"));
        Titulo_8->setAlignment(Qt::AlignCenter);
        label_13 = new QLabel(Widget);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(100, 350, 231, 31));
        label_13->setFont(font1);
        label_13->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        label_15 = new QLabel(Widget);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(350, 350, 61, 31));
        label_15->setFont(font);
        label_15->setStyleSheet(QString::fromUtf8("color: white;\n"
""));
        lineEdit = new QLineEdit(Widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(330, 730, 113, 24));
        lineEdit->setStyleSheet(QString::fromUtf8("        background-color: #ffffff;\n"
"        color: black;\n"
"        border: 1px solid #999;\n"
"        border-radius: 5px;\n"
"        padding: 5px 10px;"));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        pushButton->setText(QApplication::translate("Widget", "Abrir", nullptr));
        label_2->setText(QApplication::translate("Widget", ".", nullptr));
        label_3->setText(QApplication::translate("Widget", "RPM:", nullptr));
        Titulo->setText(QApplication::translate("Widget", "LAB 5 - EMBEBIDOS - CAMILA QUECAN, DAVID PEREZ, AHMED REYES", nullptr));
        Titulo_2->setText(QApplication::translate("Widget", "GRAFICA", nullptr));
        Titulo_3->setText(QApplication::translate("Widget", "SELECCIONE EL PUERTO", nullptr));
        Titulo_4->setText(QApplication::translate("Widget", "REVOLUCIONES POR MINUTO", nullptr));
        label_4->setText(QApplication::translate("Widget", "Rpm minima:", nullptr));
        label_5->setText(QApplication::translate("Widget", "Rpm m\303\241xima: ", nullptr));
        Titulo_5->setText(QApplication::translate("Widget", "VELOCIDAD", nullptr));
        label_6->setText(QApplication::translate("Widget", "Velocidad lineal:", nullptr));
        label_7->setText(QApplication::translate("Widget", "Velocidad angular:", nullptr));
        label_9->setText(QApplication::translate("Widget", "Ingrese velocidad (mm/s) deseada:", nullptr));
        Titulo_6->setText(QApplication::translate("Widget", "CONTROL MOTOR", nullptr));
        pushButton_2->setText(QApplication::translate("Widget", "Detener", nullptr));
        pushButton_3->setText(QApplication::translate("Widget", "Arrancar", nullptr));
        Titulo_7->setText(QApplication::translate("Widget", "DESCARGA TUS DATOS", nullptr));
        Button_log->setText(QApplication::translate("Widget", "Click para LOG", nullptr));
        label_10->setText(QApplication::translate("Widget", ".", nullptr));
        label_11->setText(QApplication::translate("Widget", ".", nullptr));
        label_12->setText(QApplication::translate("Widget", ".", nullptr));
        label_14->setText(QApplication::translate("Widget", ".", nullptr));
        pushButton_5->setText(QApplication::translate("Widget", "Enviar", nullptr));
        Titulo_8->setText(QApplication::translate("Widget", "TIEMPO EN SEGUNDOS: ", nullptr));
        label_13->setText(QApplication::translate("Widget", "TIEMPO EN SEGUNDOS: ", nullptr));
        label_15->setText(QApplication::translate("Widget", ".", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
