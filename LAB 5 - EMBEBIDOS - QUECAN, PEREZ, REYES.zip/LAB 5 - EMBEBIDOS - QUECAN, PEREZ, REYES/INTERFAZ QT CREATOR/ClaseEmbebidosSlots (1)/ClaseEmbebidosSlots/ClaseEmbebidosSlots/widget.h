#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDebug>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QVector>
#include <QFile>
#include <QTextStream>
#include <QDateTime>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void writeLog(double RPM);

private slots:
    void on_pushButton_clicked();
    void readSerial();
    void processSerial(QString datos);
    void on_Button_log_clicked();
    void on_pushButton_5_clicked();


    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    void setupPlot();
    void makeplot(double RPM, double VelociLin);

    Ui::Widget *ui;
    QVector<double> x;
    QVector<double> y;
    QVector<double> z;
    QVector<double> w;
    QSerialPort *ttl;
    QByteArray serialData;
    QString serialBuffer;
    QString parsed_data;
    uint speed;
    bool logEnabled;
    QFile logFile;
    uint32_t tiempobuild;
    double VelociLin;
};

#endif // WIDGET_H
