#include "widget.h"
#include "ui_widget.h"
#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTextStream>
#include <QTimer>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , logFile("DatoMotor.txt")
    , logEnabled(false)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: #2e2e2e;");
    ttl = new QSerialPort(this);
    serialBuffer = "";
    parsed_data = "";
    VelociLin = 0;

    uint32_t prueba = 0x4567;
    qDebug() << "Inicio el programa: " << prueba;

    foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        QString pname = info.portName();
        qDebug() << pname;
        ui->comboBox->addItem(pname);
    }

    setupPlot();

    if (!logFile.open(QIODevice::Append | QIODevice::Text)) {
        qDebug() << "No pudimos descargar tus datos";
    }
    ui->Button_log->setText("Iniciar Log");
}

Widget::~Widget()
{
    if (ttl->isOpen()) {
        ttl->close();
        QObject::disconnect(ttl, SIGNAL(readyRead()), this, SLOT(readSerial()));
    }

    if (logFile.isOpen()) {
        logFile.close();
    }

    delete ui;
}

void Widget::setupPlot()
{
    x.resize(101);
    y.resize(101);
    z.resize(101);
    w.resize(101);

    for (int i = 0; i < 101; ++i) {
        x[i] = (double)i;
        y[i] = 2.0;
        z[i] = (double)i;
        w[i] = 4.0;
    }

    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis);
    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis2);
    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->graph(1)->setData(z, w);
    ui->customPlot->graph(0)->setPen(QPen(Qt::green));
    ui->customPlot->graph(1)->setPen(QPen(Qt::magenta));
    ui->customPlot->graph(0)->setName("RPM");
    ui->customPlot->graph(1)->setName("mm/s");


    ui->customPlot->setBackground(QBrush(QColor(46, 46, 46)));
    ui->customPlot->axisRect()->setBackground(QBrush(Qt::black));


    QPen axisPen(Qt::white);
    ui->customPlot->xAxis->setBasePen(axisPen);
    ui->customPlot->yAxis->setBasePen(axisPen);
    ui->customPlot->yAxis2->setBasePen(axisPen);
    ui->customPlot->xAxis->setTickPen(axisPen);
    ui->customPlot->yAxis->setTickPen(axisPen);
    ui->customPlot->yAxis2->setTickPen(axisPen);
    ui->customPlot->xAxis->setSubTickPen(axisPen);
    ui->customPlot->yAxis->setSubTickPen(axisPen);
    ui->customPlot->yAxis2->setSubTickPen(axisPen);

    ui->customPlot->xAxis->setTickLabelColor(Qt::white);
    ui->customPlot->yAxis->setTickLabelColor(Qt::white);
    ui->customPlot->yAxis2->setTickLabelColor(Qt::white);

    ui->customPlot->xAxis->setLabelColor(Qt::white);
    ui->customPlot->yAxis->setLabelColor(Qt::white);
    ui->customPlot->yAxis2->setLabelColor(Qt::white);


    QCPTextElement *title = new QCPTextElement(ui->customPlot, "Velocidad - RPM", QFont("Times New Roman", 10, QFont::Bold));
    title->setTextColor(Qt::white);
    ui->customPlot->plotLayout()->insertRow(0);
    ui->customPlot->plotLayout()->addElement(0, 0, title);


    ui->customPlot->legend->setVisible(true);
    QFont legendFont = font();
    legendFont.setPointSize(9);
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->legend->setBrush(QBrush(Qt::black));
    ui->customPlot->legend->setTextColor(Qt::white);
    ui->customPlot->legend->setBorderPen(QPen(Qt::white));


    ui->customPlot->xAxis->setLabel("Tiempo (Seg)");
    ui->customPlot->yAxis->setLabel("RPM");
    ui->customPlot->yAxis2->setLabel("mm/s");

    ui->customPlot->xAxis->setRange(0, 100);
    ui->customPlot->yAxis->setRange(0, 5000);
    ui->customPlot->yAxis2->setRange(0, 1000);
    ui->customPlot->yAxis2->setVisible(true);

    ui->customPlot->replot();
}


void Widget::makeplot(double RPM, double Vel)
{
    for (int i = 0; i < 100; ++i) {
        y[i] = y[i + 1];
        w[i] = w[i + 1];
    }
    y[100] = RPM;
    w[100] = Vel;

    ui->customPlot->graph(0)->setData(x, y);
    ui->customPlot->graph(1)->setData(z, w);
    ui->customPlot->replot();
}

void Widget::writeLog(double RPM)
{
    if (logEnabled && logFile.isOpen()) {
        QTextStream stream(&logFile);
        stream << "RPM: " << RPM << ", Velocidad Lineal: " << VelociLin << "\n";
        stream.flush();
    }
}

void Widget::on_pushButton_clicked()
{
    if (ttl->isOpen()) {
        ttl->close();
        QObject::disconnect(ttl, SIGNAL(readyRead()), this, SLOT(readSerial()));
        ui->pushButton->setText("Abierto");
    } else {
        QString ttl_port_name = ui->comboBox->currentText();
        ttl->setPortName(ttl_port_name);
        ttl->open(QSerialPort::ReadWrite);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setFlowControl(QSerialPort::NoFlowControl);
        ttl->setParity(QSerialPort::NoParity);
        ttl->setStopBits(QSerialPort::OneStop);
        QObject::connect(ttl, SIGNAL(readyRead()), this, SLOT(readSerial()));
        ui->pushButton->setText("Cerrado");
    }
}

void Widget::readSerial()
{
    QByteArray buffer = ttl->readAll();
    qDebug() << "Datos recibidos: " << buffer;
    QString data = QString::fromUtf8(buffer);
    processSerial(data);
}

void Widget::processSerial(QString datos)
{
    if (datos.contains(",")) {
        QStringList lista = datos.split(",");
        if (lista.length() == 4) {
            double RPM = lista.at(0).toDouble();
            QString Tiempo = lista.at(1);
            QString VelociAng = lista.at(2);
            VelociLin = lista.at(3).toDouble();

            ui->label_2->setText(lista.at(0));
            ui->label_15->setText(Tiempo);
            ui->label_12->setText(VelociAng);
            ui->label_14->setText(lista.at(3));

            makeplot(RPM, VelociLin);
            writeLog(RPM);
        }
    }
}

void Widget::on_Button_log_clicked()
{
    logEnabled = !logEnabled;

    if (logEnabled) {
        ui->Button_log->setText("🟢 Grabando Log...");
        ui->Button_log->setStyleSheet("color: lightgreen;");
    } else {
        ui->Button_log->setText("🟡 Log detenido");
        ui->Button_log->setStyleSheet("color: orange;");
        QTimer::singleShot(2000, this, [=]() {
            ui->Button_log->setText("Iniciar Log");
            ui->Button_log->setStyleSheet("");
        });
    }
}

void Widget::on_pushButton_5_clicked()
{
    if (ttl && ttl->isOpen()) {
        QString textoUsuario = ui->lineEdit->text();
        textoUsuario += "\n";
        ttl->write(textoUsuario.toUtf8());
        qDebug() << textoUsuario;
    } else {
        qDebug() << "El puerto no está abierto.";
    }
}


void Widget::on_pushButton_2_clicked()
{
    if (ttl && ttl->isOpen()) {
        QString textoUsuario = 0;
        textoUsuario += "\n";
        ttl->write(textoUsuario.toUtf8());
        qDebug() << textoUsuario;
    }

}


void Widget::on_pushButton_3_clicked()
{
    if (ttl && ttl->isOpen()) {
        QString textoUsuario = QString::number(30);
        textoUsuario += "\n";
        ttl->write(textoUsuario.toUtf8());
        qDebug() << textoUsuario;
    }
}

