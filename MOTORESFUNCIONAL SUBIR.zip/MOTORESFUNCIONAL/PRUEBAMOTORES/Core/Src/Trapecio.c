
#include "Trapecio.h"


void TrapecioInit(Trapecio *Perfil, float distanciamm, float velmax, float aceleracion){
	Perfil->distanciamm = distanciamm;
	Perfil->velmax = velmax;
	Perfil->aceleracion = aceleracion;
	Perfil->distanciarecorrida = 0.0;
	Perfil->parada = 0;
	Perfil->terminado = 0;
	Perfil->velactual = 0.0;
	Perfil->velobjetivo = 0.0;
}


float TrapecioUpdate(Trapecio *Perfil, float distanciarecorrida, uint32_t deltatiempoms, uint8_t parada){
	if(Perfil->terminado == 1){
		return 0.0;
	}

	float deltatiemposeg = deltatiempoms/1000.0;
	Perfil->distanciarecorrida = distanciarecorrida;
	Perfil->parada = parada;

	float distanciafaltante = Perfil->distanciamm - distanciarecorrida;
	float distanciafrenado = (Perfil->velactual * Perfil->velactual)/(2.0 * Perfil->aceleracion);

	uint8_t necesitofrenar = (distanciafrenado >= distanciafaltante)|| (parada);

	if(necesitofrenar){
		Perfil->velactual = Perfil->velactual - (Perfil->aceleracion * deltatiemposeg);
		if (Perfil->velactual <= 0.0){
			Perfil->velactual = 0.0;
			Perfil->terminado = 1;
		}
	}

	else{
		float velocidadfutura = Perfil->velactual + (Perfil->aceleracion * deltatiemposeg);
		float distanciaaceleracion = (velocidadfutura * velocidadfutura)/(2.0 * Perfil->aceleracion);
		if (distanciaaceleracion < distanciafaltante && Perfil->velactual < Perfil->velmax){
			Perfil->velactual = Perfil->velactual + (Perfil->aceleracion * deltatiemposeg);
			if(Perfil->velactual > Perfil->velmax){
				Perfil->velactual = Perfil->velmax;
			}
		}
	}

	if(distanciafaltante <= 0.1){
		Perfil->velactual = 0;
		Perfil->terminado = 1;
	}

	return(Perfil->velactual);

}

uint8_t trapeciofinalizado(Trapecio *Perfil){
	return(Perfil->terminado);
}
