/*
 * Trapecio.h
 *
 *  Created on: May 21, 2025
 *      Author: queca
 */

#ifndef INC_TRAPECIO_H_
#define INC_TRAPECIO_H_
#include "main.h"

typedef struct{
	float distanciamm;
	float velmax;
	float aceleracion;
	float velactual;
	float velobjetivo;
	float distanciarecorrida;
	uint8_t parada;
	uint8_t terminado;
}Trapecio;

void TrapecioInit(Trapecio *Perfil, float distanciamm, float velmax, float aceleracion);

float TrapecioUpdate(Trapecio *Perfil, float distanciarecorrida, uint32_t deltatiempoms, uint8_t parada);

uint8_t trapeciofinalizado(Trapecio *Perfil);

#endif /* INC_TRAPECIO_H_ */
